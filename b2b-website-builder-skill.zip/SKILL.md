---
name: b2b-website-builder
description: |
  外贸独立站与企业官网全栈搭建与运营实战技能。涵盖云服务器LNMP环境配置、动静分离混合架构（静态主站 + WordPress动态博客）、Nginx路由与防重定向死循环配置、高抗垃圾邮件与MySQL落盘的企业级询盘表单系统（PHP+SMTP）、多语言LLM翻译与RTL布局修复、以及Google SEO与GEO（生成式AI引擎）全套优化规范。
  触发场景：
  - 用户需要搭建外贸独立站、出海展示站、B2B企业官网或营销落地页。
  - 需要配置Nginx动静分离架构、排查WordPress重定向死循环（ERR_TOO_MANY_REDIRECTS）或502错误。
  - 需要开发或优化真实可接收的外贸询盘表单系统（支持蜜罐反爬、数据库防丢单、SMTP邮件即时推送）。
  - 需要对网站进行海外加速（CDN配置）、多语言本地化或实施SEO/GEO规则改造。
---

# B2B 外贸网站全栈搭建与运营专家技能 (B2B Website Builder)

本技能沉淀自真实的阿里云ECS生产环境与外贸出海站部署实战，旨在帮助Agent以最高工程质量、最快速度交付具备极高海外转化率和AI搜索引擎（GEO）权威度的高性能企业网站。

---

## 核心架构原则：动静分离混合架构 (Hybrid Architecture)

外贸出海站必须兼顾**毫秒级首屏加载**与**内容长效更新**。默认架构为：
- **静态根目录 `/`**：手写轻量HTML5/CSS3，承载首页、产品矩阵、解决方案、MSDS技术中心与联系页。
- **动态子目录 `/news/`**：部署WordPress独立实例，承载行业博客、技术对比长文与SEO/GEO文章。

---

## 阶段一：底层服务器与环境搭建规范 (Infrastructure)

### 1. 网络与端口基线
- 云服务器（如阿里云ECS）安全组必须显式放行：`22` (SSH), `80` (HTTP), `443` (HTTPS), 面板端口 (如宝塔默认或自定义高位端口)。
- 域名接入：国内服务器必须具备ICP企业主体备案；面向海外的站点必须接入Cloudflare CDN以降低TTFB（首字节延迟）。

### 2. LNMP 环境配置与故障排查
- **Nginx + MySQL 5.7+ + PHP 7.4/8.0**。
- **502 Bad Gateway 排查**：检查PHP-FPM进程状态，确认Nginx配置文件中的 `fastcgi_pass` 路径（Unix Socket vs TCP 9000）与PHP版本一致。
- **命令行强行部署官方WordPress**（面板超时/白屏时通用方案）：
  ```bash
  cd /www/wwwroot/YOUR_DOMAIN
  rm -rf * && wget https://cn.wordpress.org/latest-zh_CN.zip && unzip latest-zh_CN.zip && mv wordpress/* . && rm -rf wordpress latest-zh_CN.zip
  chown -R www:www /www/wwwroot/YOUR_DOMAIN
  ```

---

## 阶段二：Nginx路由分流与防死循环配置 (Routing & Anti-Redirect)

### 1. Nginx 动静分离配置文件（见 templates/nginx_hybrid.conf）
静态根目录走 `try_files $uri $uri/ =404;`，WordPress走子目录重写 `try_files $uri $uri/ /news/index.php?$args;`。

### 2. 攻克 WordPress 子目录 301 重定向死循环 (ERR_TOO_MANY_REDIRECTS)
WordPress内核的 `redirect_canonical` 函数会误将子目录请求规范化至根域名。必须在 `wp-content/mu-plugins/` 中置入强制过滤脚本（见 `templates/disable_canonical.php`）：
```php
<?php
/* Plugin Name: Disable Subdirectory Canonical Redirect */
remove_filter('template_redirect', 'redirect_canonical');
```

---

## 阶段三：真实可达的企业级询盘系统闭环 (Lead Capture System)

严禁直接调用Linux本地未授权的 `mail()` 函数。必须实施四重防护闭环：
1. **前端异步无刷新提交**（`templates/contact_form.html`）：使用原生 Fetch API，用户提交无需跳转刷新页面。
2. **蜜罐反爬虫（Honeypot）**：表单内注入隐藏字段 `<input type="text" name="honeypot_check" style="display:none;">`，后台一旦检测到该字段非空，立即判定为爬虫机器人并静默丢弃。
3. **数据库优先落盘（防丢单底线）**：发信前强制写入 MySQL 数据表（`wp_kx_leads`），确保即便邮件网络抖动，商机信息永不丢失。
4. **企业邮箱 SMTP 安全握手**（`templates/submit_lead.php`）：直连阿里云企业邮箱等服务商的 SSL 465 端口授权发信，毫秒级推送至业务管理员邮箱。

---

## 阶段四：海外买家体验 (Buyer UX) 与 SEO/GEO 优化标准

### 1. 欧美B2B采购商阅读心理与排版动线
- **客观事实密度**：用“产能吨数、检测纯度、认证编号、出厂指标”取代泛化宣传词（如“No.1 / Best”）。
- **F型扫视动线**：首屏 3 秒明确核心产品与资质；核心参数必须为 HTML 可复制表格，严禁全图切片；MSDS/TDS/COA 设立专属技术中心。
- **多触点转化**：右下角常驻带专属预设文本的 WhatsApp 沟通浮窗，表单字段精简至 4~5 项。

### 2. SEO & GEO（生成式AI引擎优化）双驱基线
- **开放式 robots.txt**（`templates/robots.txt`）：显式放行 GoogleBot、Baiduspider 及 GPTBot、ClaudeBot、PerplexityBot。
- **Schema.org JSON-LD 嵌入**（`templates/schema_jsonld_template.html`）：为全站注入 `Organization`、`Product` 与 `FAQPage` 结构化代码。
- **语义化英文 Slug 规则**：博客短网址统一采用英文小写关键词（如 `/news/sdic-vs-tcca-chlorine-comparison/`），杜绝中文拼音与动态数字ID。

---

## 阶段五：自动化运维与多语言本地化 (DevOps & Localization)

1. **Python 自动化运维脚本**：利用本地脚本（`scripts/bt_push.py`）直连服务器进行热更新与代码同步。
2. **定时探活与日志监控**：通过宝塔 Crontab 挂载探活脚本（`scripts/health_check_cron.sh`），异常自动记录并告警。
3. **多语言与 RTL 规范**：使用 LLM 预翻译时冻结化学术语、CAS 编号与规格数字；针对阿拉伯语环境注入 RTL 专属 CSS 补丁，修复 Flex 镜像冲突。
