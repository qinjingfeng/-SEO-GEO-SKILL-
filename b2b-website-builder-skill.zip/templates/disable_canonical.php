<?php
/**
 * Plugin Name: Disable Subdirectory Canonical Redirect (Anti-Loop)
 * Plugin URI:  https://github.com/b2b-website-builder
 * Description: 强制禁用 WordPress 内核对子目录运行时的 canonical 规范重定向，彻底解决 ERR_TOO_MANY_REDIRECTS 301 死循环。
 * Version:     1.0.0
 * Author:      B2B Website Builder
 * 
 * 安装路径: 将本文件放置在 WordPress 的 wp-content/mu-plugins/ 目录下（无需手动激活，自动全局生效）
 */

// 阻止直接访问
if (!defined('ABSPATH')) {
    exit;
}

// 移除 WordPress 模板重定向中的规范化检查钩子
remove_filter('template_redirect', 'redirect_canonical');
