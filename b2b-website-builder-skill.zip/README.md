# B2B 外贸网站全栈搭建与运营 Skill 技能说明书

## 1. 技能定位与价值
本技能包汇集了我们在外贸独立站（如化工 SDIC/TCCA 站）与国内企业官网（楷轩网络官网）全生命周期实战中沉淀的**完整工程方案、排错脚本、代码模板与运营规范**。

后续使用本技能包，任何 Agent 或技术开发人员都可以跳过摸索与踩坑阶段，直接实现：
- **混合动静分离架构**一键配置（毫秒级加载 + 动态博客运营）
- **WordPress 核心死循环故障**一秒排除
- **零漏单外贸询盘表单系统**（蜜罐反爬 + 数据库优先落盘 + 阿里云企业邮箱 SMTP 即时推送）
- **海外买家 F 型阅读动线与高转化设计规范**
- **Google SEO + 生成式 AI 引擎（GEO）**的双驱标准化落地

---

## 2. 技能包文件目录清单

```
b2b-website-builder-skill/
│
├── SKILL.md                          # 技能核心指导指令（供 AI 驱动执行）
├── README.md                         # 技能说明文档（本文件）
│
├── templates/                        # 生产级代码模板
│   ├── nginx_hybrid.conf             # Nginx 动静分离与子目录 WP 伪静态标准配置
│   ├── disable_canonical.php         # 解决 WP 子目录重定向死循环的 Must-Use 插件
│   ├── contact_form.html             # 集成 Honeypot 与 AJAX 异步提交的前端外贸询盘表单
│   ├── submit_lead.php               # 防丢单数据库落盘 + SMTP 邮件提醒完整后端脚本
│   ├── robots.txt                    # 适配主流搜索引擎与 AI 爬虫（GPTBot等）的标准规则
│   └── schema_jsonld_template.html   # B2B 独立站核心 JSON-LD 结构化数据模板
│
└── scripts/                          # 自动化运维工具与脚本
    ├── bt_push.py                    # 本地代码与配置一键同步至宝塔/服务器脚本模板
    └── health_check_cron.sh          # Linux Crontab 定时探活与访问状态监控脚本
```

---

## 3. 核心功能与使用指南

### ① 架构搭建（静态主站 + /news/ 博客）
1. 复制 `templates/nginx_hybrid.conf` 内容至宝塔或 Nginx 的站点配置文件中，将域名和路径替换为实际项目。
2. 在 WordPress 安装完成后，将 `templates/disable_canonical.php` 复制到 `/www/wwwroot/YOUR_DOMAIN/news/wp-content/mu-plugins/` 目录中，确保子目录博客绝不陷入 301 循环。

### ② 部署高转化询盘系统
1. 前端：在联系页面中引入 `templates/contact_form.html` 的表单代码与 JS 提交逻辑。
2. 数据库：在 MySQL 中执行 `CREATE TABLE` 创建 `wp_kx_leads` 数据表。
3. 后端：将 `templates/submit_lead.php` 放置在网站目录，修改其中的数据库密码与企业邮箱 SMTP 授权密码。

### ③ SEO 与 GEO 搜索引擎接入
1. 部署 `templates/robots.txt` 至网站根目录，放行 GoogleBot、Baiduspider、GPTBot、ClaudeBot、PerplexityBot 等高价值抓取爬虫。
2. 提取 `templates/schema_jsonld_template.html` 中的代码，填入真实企业名称、产品参数与行业 FAQ，嵌入核心页面的 `<head>` 中。

---

## 4. 安装与激活说明
- **Agent 本地技能库安装**：已同步安装至 Agent 的本地专属技能目录：
  `agent-core/skills/b2b-website-builder/`
- **便携安装与迁移**：可直接使用打包好的 `b2b-website-builder-skill.zip` 压缩包，复制到任何运行环境中解压即用。
