#!/bin/bash
# =========================================================================
# 网站可用性自动化探活脚本 (挂载至 Linux Crontab / 宝塔计划任务)
# 功能：周期性检测主站与动态博客 HTTP 状态码，异常自动记录告警日志
# =========================================================================

LOG_FILE="/www/wwwroot/health_check.log"
TARGET_SITES=(
    "http://127.0.0.1"
    "http://127.0.0.1/news/"
)

TIMESTAMP=$(date "+%Y-%m-%d %H:%M:%S")

for url in "${TARGET_SITES[@]}"; do
    HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" -m 10 "$url")
    
    if [ "$HTTP_CODE" -eq 200 ] || [ "$HTTP_CODE" -eq 301 ] || [ "$HTTP_CODE" -eq 302 ]; then
        # 状态正常（可选记录或留空）
        echo "[$TIMESTAMP] OK: $url (HTTP $HTTP_CODE)" >> "$LOG_FILE"
    else
        # 异常状态记录并触发警报
        echo "[$TIMESTAMP] ALERT: $url returned HTTP $HTTP_CODE" >> "$LOG_FILE"
        
        # 可选：如果 502 则自动尝试重启 PHP 服务（需 root 权限）
        if [ "$HTTP_CODE" -eq 502 ]; then
            echo "[$TIMESTAMP] Attempting to reload PHP-FPM service..." >> "$LOG_FILE"
            systemctl reload php-fpm || systemctl reload php-fpm-74 || systemctl reload php-fpm-80
        fi
    fi
done

# 保留最近 1000 行日志防止膨胀
tail -n 1000 "$LOG_FILE" > "${LOG_FILE}.tmp" && mv "${LOG_FILE}.tmp" "$LOG_FILE"
