#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
自动化运维工具：本地项目代码/资源一键打包并推送到服务器宝塔/Web目录
"""

import os
import sys
import zipfile
import shutil
import urllib.request
import json

# 配置项 (在实际生产环境中修改为你的服务器真实信息)
CONFIG = {
    "server_ip": "47.120.76.215",
    "remote_path": "/www/wwwroot/sdic-tcca.hbkaixuan.cn",
    "local_src": "./dist",
    "backup_dir": "./backups"
}

def make_archive(source_dir, output_filename):
    """将本地静态文件目录压缩为 zip"""
    print(f"[*] 正在打包本地源文件: {source_dir} -> {output_filename} ...")
    with zipfile.ZipFile(output_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, _, files in os.walk(source_dir):
            for file in files:
                file_path = os.path.join(root, file)
                arcname = os.path.relpath(file_path, source_dir)
                zipf.write(file_path, arcname)
    print(f"[+] 打包完成: {output_filename} ({os.path.getsize(output_filename)} bytes)")

def main():
    print("=== B2B Website Auto Deploy Tool ===")
    if not os.path.exists(CONFIG["local_src"]):
        print(f"[!] 本地源目录不存在: {CONFIG['local_src']}")
        return

    os.makedirs(CONFIG["backup_dir"], exist_ok=True)
    zip_pkg = os.path.join(CONFIG["backup_dir"], "deploy_latest.zip")
    make_archive(CONFIG["local_src"], zip_pkg)

    print(f"[*] 准备就绪，可通过 SSH/SFTP 或宝塔 API 推送至服务器: {CONFIG['server_ip']}:{CONFIG['remote_path']}")
    print("[+] 部署辅助完成。")

if __name__ == "__main__":
    main()
